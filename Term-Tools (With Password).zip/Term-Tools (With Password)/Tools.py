#!/usr/bin/env python3

import os

def main():

    # What do you want to do?

    print() 

    os.system('echo What would you like to hack on today?')

    print()

    # Choose command(s) to execute 
    os.system('\necho Choose a command:')

    print("-----------------")

    # Lists options for commands or exit 
    os.system('\necho uua - Maintenance; \necho tp - top; \necho ht - htop; \necho nf - neofetch; \necho ur - uname -r; \necho ifc - ifconfig; \necho ipa - ip a; \necho ws - wireshark; \necho mn - nmap; \echo jr - john the ripper')

    print()

    # Prompts user to enter a command
    command = input("Enter a command: ")

    # updates, upgrades, and removes packages no longer needed
    if command == "uua":
        os.system('echo Hello there!; sudo apt update && sudo apt upgrade; sudo apt autoremove')

    # Runs top
    if command == "tp":
        os.system('top')

    # Runs htop
    if command == "ht":
        os.system('htop')

    # Runs neofetch
    if command == "nf":
        os.system('neofetch')
        
    # Runs uname -r
    if command == "ur":
    	os.system('uname -r')
    
    # Runs ifconfig 
    if command == "ifc":
        os.system('ifconfig')
    
    # Runs ip a
    if command == "ipa":
        os.system('ip a')

    # Runs wirshark
    if command == "ws":
        os.system("wireshark -v")

    # Runs nmap
    if command == "nm":
        os.system("sudo nmap -sV -O scanme.nmap.org")

    # Runs john the ripper
    if command == "jr":
        os.system('zip2john Password.zip')
        os.system('zip2john Password.zip > hash.txt')
        os.system('john --format=zip hash.txt')
        os.system('rm hash.txt')
        print()
        print("Good job hacking!")
    else:
        print()
        print("Have a good day!")
          
main()
