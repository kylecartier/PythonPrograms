import os

def main():

    word = input("Enter a word: ")

    if word == "hack":
        os.system('./jr.py') 
    else:
        print()
        print("Have a good day!")

main()
